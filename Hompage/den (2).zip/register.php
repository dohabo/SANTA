<!doctype html>
<html>
<head>
  <meta charset='utf-8'>
</head>
<body>
  <?php
  echo "국어 : ",$_REQUEST["kor"],"<br>";
  echo "영어 : ",$_REQUEST["eng"],"<br>";
  echo "수학 : ",$_REQUEST["math"];
  $name = $_POST['Name'];
    echo "당신의 이름은 : $name";
  ?>
</body>
</html>